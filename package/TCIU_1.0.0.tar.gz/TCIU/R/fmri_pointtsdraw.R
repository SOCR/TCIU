#' @title fmri_pointtsdraw
#' @description a function to forecast the fMRI data based on the time series
#'
#' @param SmoothM a 4D array contains information for the fMRI spacetime image. The data should only contains the magnitude for the fMRI image.
#' @param x voxel location for the x axis
#' @param y voxel location for the y axis
#' @param z voxel location for the z axis
#' @param cut cut of the data. The default is 10. 
#'
#' @details The function \code{fmri_pointtsdraw} is used to forecast with time series.
#'
#' @author SOCR team <\url{http://socr.umich.edu/people/}>
#'
#' @return a figure forecasting the voxel with time series
#' @export
#' @import zoo plotly
#' @importFrom stats time
#' @importFrom forecast auto.arima forecast
#' 
#' @examples
#' require('AnalyzeFMRI')
#' fmri_generate = fmri_simulate_func(dim_data = c(64, 64, 40), mask = mask)
#' smoothmod <- AnalyzeFMRI::GaussSmoothArray(fmri_generate$fmri_data, sigma = diag(3,3))
#' fmri_pointtsdraw(smoothmod,41,44,33)

fmri_pointtsdraw <- function(SmoothM, x, y, z, cut = 10) {
    data = detrend(SmoothM[x, y, z, ], bp = seq(21, 160, by = cut))
    trainData <- data[3:132]
    testData <- ts(data[133:160], start = 131, end = 158)
    arimaMod <- auto.arima(trainData, stepwise = FALSE, approximation = FALSE)
    TSplot_gen(130, arimaMod, periods = 28, ts_list = list(testData))
}
