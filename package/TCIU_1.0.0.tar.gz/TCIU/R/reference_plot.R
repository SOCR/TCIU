#' @title reference_plot
#'
#' @description a reference \code{plotly} object for the function \code{fmri_complex_draw}
#'
#' @docType data
#' @keywords plotly object
#' @name reference_plot
#' @usage reference_plot
#' @format a \code{plotly} object showing the HRF function
#'
NULL
