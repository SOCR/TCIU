#' @title mask
#'
#' @description a 64*64*40 3D array representing brain mask
#'
#' @docType data
#' @keywords array
#' @name mask
#' @usage mask
#' @format a 3D array containing brain mask data
#'
NULL
