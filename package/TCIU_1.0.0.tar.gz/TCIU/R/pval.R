#' @title pval
#'
#' @description a 64*64*40 3D array containing p values
#'
#' @docType data
#' @keywords array
#' @name pval
#' @usage pval
#' @format a 3D array containing p values
#'
NULL
