#' @title sample_voxel
#'
#' @description a sample vector with length 160 representing the value of a single complex-valued fMRI voxel for the function \code{fmri_complex_draw}
#'
#' @docType data
#' @keywords vector
#' @name sample_voxel
#' @usage sample_voxel
#' @format a vector with length 160
#'
NULL
