#' @title mask_label
#'
#' @description a 64*64*40 3D array representing brain mask with labels
#'
#' @docType data
#' @keywords array
#' @name mask_label
#' @usage mask_label
#' @format a 3D array containing brain mask data
#'
NULL
