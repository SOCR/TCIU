#' @title mask_dict
#'
#' @description a data.frame containing the label index corresponding to its label name
#'
#' @docType data
#' @keywords data.frame
#' @name mask_dict
#' @usage mask_dict
#' @format a data.frame containing the label index corresponding to its label name
#'
NULL
