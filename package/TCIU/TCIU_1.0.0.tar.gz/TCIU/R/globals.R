utils::globalVariables(c("colorgrp", "corresp_color", "x", "y", "one_minus_p", ".", "p_value", "bin", "p_value_name", "Freq", "plotVal", 
    "volume", "%$%", "%dopar%", "foreach", "makeCluster", "stopCluster", "packageVersion", "points"))
