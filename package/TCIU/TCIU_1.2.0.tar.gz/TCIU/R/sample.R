#' @title sample
#'
#' @description a data.frame containing some pre-calculated data for generating vignettes
#'
#' @docType data
#' @keywords data.frame
#' @name sample
#' @usage sample
#' @format a data.frame containing some pre-calculated data for generating vignettes
#'
NULL
