1) Create a virtual environment:

virtualenv -m venv env

2) install requirements as an when needed per the packages that will be used.
 
pip install requirements.txt

