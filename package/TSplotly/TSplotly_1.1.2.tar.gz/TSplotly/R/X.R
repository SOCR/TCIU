#' @title X
#'
#' @description an external regressor working on function \code{auto.arima()}. It changes a regular ARIMA model into ARIMAX model
#'
#' @docType data
#' @keywords matrix
#' @name X
#' @usage X
#' @format a matrix serving as the external regressor
#'
NULL