#' @title MCSI_Data_monthAvg_ts_Y
#'
#' @description time series data working on function \code{TSplot}
#'
#' @docType data
#' @keywords time-series dataset
#' @name MCSI_Data_monthAvg_ts_Y
#' @usage MCSI_Data_monthAvg_ts_Y
#' @format a vector kind dataset created by function \code{ts()}
#'
NULL