#' @title Y
#'
#' @description information of a time series dataset.
#'
#' @docType data
#' @keywords vector
#' @name Y
#' @usage Y
#' @format a vector
#'
NULL