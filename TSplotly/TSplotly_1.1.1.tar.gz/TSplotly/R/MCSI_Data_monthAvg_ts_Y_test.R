#' @title MCSI_Data_monthAvg_ts_Y_test
#'
#' @description time series data working on function \code{TSplot_gen}
#'
#' @docType data
#' @keywords time-series dataset
#' @name MCSI_Data_monthAvg_ts_Y_test
#' @usage MCSI_Data_monthAvg_ts_Y_test
#' @format a vector kind dataset created by function \code{ts()}
#'
NULL